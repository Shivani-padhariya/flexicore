"use client"

import { ExternalLink, Heart, MessageCircle, Instagram } from "lucide-react"

/**
 * Home section §4.9
 * Dedicated Instagram grid — each tile opens the original IG post in a new tab.
 */

type Post = {
  id: string
  image: string
  url: string
  caption: string
  likes: number
  comments: number
}

const posts: Post[] = [
  {
    id: "ig1",
    image: "/instagram-post-marble-kitchen.jpg",
    url: "https://www.instagram.com/",
    caption: "Calacatta Greige flows seamlessly across this Madrid loft kitchen.",
    likes: 2844,
    comments: 64,
  },
  {
    id: "ig2",
    image: "/instagram-post-bathroom-vanity.jpg",
    url: "https://www.instagram.com/",
    caption: "Ivory Linen vanity - quiet luxury, honest materials.",
    likes: 1902,
    comments: 31,
  },
  {
    id: "ig3",
    image: "/instagram-post-reception-desk.jpg",
    url: "https://www.instagram.com/",
    caption: "Noir Obsidian reception at Kyoto hotel lobby.",
    likes: 3217,
    comments: 88,
  },
  {
    id: "ig4",
    image: "/instagram-post-factory-behind-scenes.jpg",
    url: "https://www.instagram.com/",
    caption: "Behind the scenes - pour day on line three.",
    likes: 1240,
    comments: 19,
  },
  {
    id: "ig5",
    image: "/instagram-post-backlit-onyx-bar.jpg",
    url: "https://www.instagram.com/",
    caption: "Honey Onyx, backlit. Bar top as sculpture.",
    likes: 4580,
    comments: 112,
  },
  {
    id: "ig6",
    image: "/instagram-post-designer-interview.jpg",
    url: "https://www.instagram.com/",
    caption: "In conversation with Studio Kano on material honesty.",
    likes: 1687,
    comments: 42,
  },
  {
    id: "ig7",
    image: "/instagram-post-hospitality-spa.jpg",
    url: "https://www.instagram.com/",
    caption: "Azure Mosaic spa wellness suite - Maldives.",
    likes: 2961,
    comments: 71,
  },
  {
    id: "ig8",
    image: "/instagram-post-showroom-launch.jpg",
    url: "https://www.instagram.com/",
    caption: "Milan showroom launch - thank you for a full house.",
    likes: 3804,
    comments: 96,
  },
]

function formatCount(n: number) {
  return n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n)
}

export function HomeInstagramGrid() {
  return (
    <section className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-10">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 text-xs tracking-[0.3em] uppercase text-accent mb-3">
              <Instagram className="h-3.5 w-3.5" />
              <span>@flexicore</span>
            </span>
            <h2 className="text-balance text-3xl md:text-5xl font-light text-primary">
              Follow our Instagram.
            </h2>
            <p className="text-pretty text-muted-foreground leading-relaxed mt-3">
              A visual diary of surfaces, studios, and stories. Tap any post to open
              the original on Instagram.
            </p>
          </div>
          <a
            href="https://www.instagram.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 self-start md:self-end bg-primary hover:bg-accent text-primary-foreground px-6 py-3 text-xs uppercase tracking-[0.3em] transition-colors duration-250"
          >
            <Instagram className="h-4 w-4" />
            Follow us
          </a>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-1.5 md:gap-2">
          {posts.map((p) => (
            <a
              key={p.id}
              href={p.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative block aspect-square overflow-hidden bg-muted"
              aria-label={`Open Instagram post: ${p.caption}`}
            >
              <div
                className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-110"
                style={{ backgroundImage: `url(${p.image})` }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              <ExternalLink
                className="absolute top-3 right-3 h-4 w-4 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                aria-hidden="true"
              />

              <div className="absolute inset-x-0 bottom-0 p-3 md:p-4 text-white translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                <p className="text-[11px] md:text-xs leading-snug line-clamp-2 mb-2">
                  {p.caption}
                </p>
                <div className="flex items-center gap-3 text-[11px]">
                  <span className="inline-flex items-center gap-1">
                    <Heart className="h-3.5 w-3.5" />
                    {formatCount(p.likes)}
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <MessageCircle className="h-3.5 w-3.5" />
                    {formatCount(p.comments)}
                  </span>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  )
}
