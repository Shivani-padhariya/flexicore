"use client"

const updates = [
  "🎉 New Launch: Introducing Aurora Collection - 25 stunning new colors",
  "📍 Visit us at AceTech Mumbai 2026 - Booth A-42",
  "🌿 Flexicore achieves Green Building Certification",
  "🏆 Winner of Best Manufacturer Award 2025",
  "📦 Free shipping on orders above ₹50,000",
  "🔥 Limited offer: 20% off on Marble Collection",
]

export function DailyUpdates() {
  return (
    <div className="bg-primary text-primary-foreground py-3 overflow-hidden">
      <div className="flex animate-scroll whitespace-nowrap">
        {[...updates, ...updates].map((update, index) => (
          <span key={index} className="mx-8 text-sm font-medium">
            {update}
          </span>
        ))}
      </div>

      <style jsx>{`
        @keyframes scroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
        .animate-scroll {
          animation: scroll 40s linear infinite;
        }
      `}</style>
    </div>
  )
}
