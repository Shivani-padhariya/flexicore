"use client"

import { useEffect, useState, useRef } from "react"

const stats = [
  { value: 25, suffix: "+", label: "Years Experience" },
  { value: 500, suffix: "+", label: "Product Colors" },
  { value: 50, suffix: "+", label: "Countries Export" },
  { value: 10000, suffix: "+", label: "Projects Completed" },
]

function AnimatedCounter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0)
  const ref = useRef<HTMLDivElement>(null)
  const hasAnimated = useRef(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true
          const duration = 2000
          const steps = 60
          const increment = value / steps
          let current = 0

          const timer = setInterval(() => {
            current += increment
            if (current >= value) {
              setCount(value)
              clearInterval(timer)
            } else {
              setCount(Math.floor(current))
            }
          }, duration / steps)
        }
      },
      { threshold: 0.5 }
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [value])

  return (
    <div ref={ref} className="text-4xl md:text-5xl font-bold text-primary">
      {count.toLocaleString()}{suffix}
    </div>
  )
}

export function AboutSection() {
  return (
    <section className="py-20 px-6 lg:px-12 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div>
            <span className="text-primary font-medium text-sm tracking-wider uppercase mb-4 block">
              About Flexicore
            </span>
            <h2 className="text-3xl md:text-4xl font-light text-foreground mb-6 text-balance">
              Redefining Solid Surfaces Since 1999
            </h2>
            <div className="space-y-4 text-muted-foreground">
              <p>
                Flexicore is a Rajkot-based manufacturer of premium solid surfaces and tiles, 
                serving architects, designers, and homeowners across India and 50+ countries worldwide.
              </p>
              <p>
                Our state-of-the-art manufacturing facility combines cutting-edge technology with 
                traditional craftsmanship to create surfaces that are not just beautiful, but built to last.
              </p>
              <p>
                From concept to completion, we partner with you to bring your creative vision to life 
                with surfaces that inspire.
              </p>
            </div>
            <a
              href="/about"
              className="inline-flex items-center gap-2 text-primary font-semibold mt-8 hover:gap-4 transition-all"
            >
              Learn More About Us
              <span>→</span>
            </a>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-8">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="bg-white border border-border p-8 text-center"
              >
                <AnimatedCounter value={stat.value} suffix={stat.suffix} />
                <p className="text-muted-foreground mt-2">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
